# README
<!-- create time: 2014-05-15 22:27:05  -->

这是Marboo的Markdown扩展包，包含功能如下：

- md文件使用pandoc来渲染
- 格式为 `*.remark.md` 的文件支持用Markdown来写remark.js格式的幻灯片
- gesh格式 
